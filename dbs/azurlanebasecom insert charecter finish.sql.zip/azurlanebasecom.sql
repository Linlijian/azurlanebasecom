-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 19, 2017 at 06:10 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `azurlanebasecom`
--

-- --------------------------------------------------------

--
-- Table structure for table `beginstatus`
--

CREATE TABLE `beginstatus` (
  `id` int(11) NOT NULL,
  `beginstatus` varchar(100) CHARACTER SET utf8 NOT NULL,
  `hp` int(11) NOT NULL,
  `def` varchar(11) CHARACTER SET utf8 NOT NULL,
  `cd` int(11) NOT NULL,
  `atk` int(11) NOT NULL,
  `atkTPD` int(11) NOT NULL,
  `dodge` int(11) NOT NULL,
  `defFly` int(11) NOT NULL,
  `atkFly` int(11) NOT NULL,
  `depetion` int(11) NOT NULL,
  `speed` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `beginstatus`
--

INSERT INTO `beginstatus` (`id`, `beginstatus`, `hp`, `def`, `cd`, `atk`, `atkTPD`, `dodge`, `defFly`, `atkFly`, `depetion`, `speed`) VALUES
(1, 'ch1', 100, 'Light', 50, 10, 10, 50, 10, 10, 2, 35);

-- --------------------------------------------------------

--
-- Table structure for table `charecter`
--

CREATE TABLE `charecter` (
  `id` int(11) NOT NULL,
  `charectorID` int(3) NOT NULL,
  `picture` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `beginStatus` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `skill` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `introduce` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `reModel` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `cusTom` varchar(11) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `charecter`
--

INSERT INTO `charecter` (`id`, `charectorID`, `picture`, `status`, `beginStatus`, `skill`, `introduce`, `reModel`, `cusTom`) VALUES
(1, 1, 'ch1.png', 'ch1', 'ch1', 'ch1', 'ch1', 'NULL', 'NULL'),
(2, 2, 'ch2.png', 'ch2', 'ch2', 'ch2', 'ch2', 'NULL', 'NULL'),
(3, 3, 'ch3.png', 'ch3', 'ch3', 'ch3', 'ch3', 'ch3', 'ch3'),
(4, 4, 'ch4.png', 'ch4', 'ch4', 'ch4', 'ch4', 'ch4', 'ch4'),
(5, 5, 'ch5.png', 'ch5', 'ch5', 'ch5', 'ch5', 'ch5', 'ch5'),
(6, 6, 'ch6.png', 'ch6', 'ch6', 'ch6', 'ch6', 'ch6', 'ch6'),
(7, 7, 'ch7.png', 'ch7', 'ch7', 'ch7', 'ch7', 'ch7', 'ch7'),
(8, 8, 'ch8.png', 'ch8', 'ch8', 'ch8', 'ch8', 'ch8', 'ch8'),
(9, 9, 'ch9.png', 'ch9', 'ch9', 'ch9', 'ch9', 'ch9', 'ch9'),
(10, 10, 'ch10.png', 'ch10', 'ch10', 'ch10', 'ch10', 'ch10', 'ch10'),
(11, 11, 'ch11.png', 'ch11', 'ch11', 'ch11', 'ch11', 'ch11', 'ch11'),
(12, 12, 'ch12.png', 'ch12', 'ch12', 'ch12', 'ch12', 'ch12', 'ch12'),
(13, 13, 'ch13.png', 'ch13', 'ch13', 'ch13', 'ch13', 'ch13', 'ch13'),
(14, 14, 'ch14.png', 'ch14', 'ch14', 'ch14', 'ch14', 'ch14', 'ch14'),
(15, 15, 'ch15.png', 'ch15', 'ch15', 'ch15', 'ch15', 'ch15', 'ch15'),
(16, 16, 'ch16.png', 'ch16', 'ch16', 'ch16', 'ch16', 'ch16', 'ch16'),
(17, 17, 'ch17.png', 'ch17', 'ch17', 'ch17', 'ch17', 'ch17', 'ch17'),
(18, 18, 'ch18.png', 'ch18', 'ch18', 'ch18', 'ch18', 'ch18', 'ch18'),
(19, 19, 'ch19.png', 'ch19', 'ch19', 'ch19', 'ch19', 'ch19', 'ch19'),
(20, 20, 'ch20.png', 'ch20', 'ch20', 'ch20', 'ch20', 'ch20', 'ch20'),
(21, 21, 'ch21.png', 'ch21', 'ch21', 'ch21', 'ch21', 'ch21', 'ch21'),
(22, 22, 'ch22.png', 'ch22', 'ch22', 'ch22', 'ch22', 'ch22', 'ch22'),
(23, 23, 'ch23.png', 'ch23', 'ch23', 'ch23', 'ch23', 'ch23', 'ch23'),
(24, 24, 'ch24.png', 'ch24', 'ch24', 'ch24', 'ch24', 'ch24', 'ch24'),
(25, 25, 'ch25.png', 'ch25', 'ch25', 'ch25', 'ch25', 'ch25', 'ch25'),
(26, 26, 'ch26.png', 'ch26', 'ch26', 'ch26', 'ch26', 'ch26', 'ch26'),
(27, 27, 'ch27.png', 'ch27', 'ch27', 'ch27', 'ch27', 'ch27', 'ch27'),
(28, 28, 'ch28.png', 'ch28', 'ch28', 'ch28', 'ch28', 'ch28', 'ch28'),
(29, 29, 'ch29.png', 'ch29', 'ch29', 'ch29', 'ch29', 'ch29', 'ch29'),
(30, 30, 'ch30.png', 'ch30', 'ch30', 'ch30', 'ch30', 'ch30', 'ch30'),
(31, 31, 'ch31.png', 'ch31', 'ch31', 'ch31', 'ch31', 'ch31', 'ch31'),
(32, 32, 'ch32.png', 'ch32', 'ch32', 'ch32', 'ch32', 'ch32', 'ch32'),
(33, 33, 'ch33.png', 'ch33', 'ch33', 'ch33', 'ch33', 'ch33', 'ch33'),
(34, 34, 'ch34.png', 'ch34', 'ch34', 'ch34', 'ch34', 'ch34', 'ch34'),
(35, 35, 'ch35.png', 'ch35', 'ch35', 'ch35', 'ch35', 'ch35', 'ch35'),
(36, 36, 'ch36.png', 'ch36', 'ch36', 'ch36', 'ch36', 'ch36', 'ch36'),
(37, 37, 'ch37.png', 'ch37', 'ch37', 'ch37', 'ch37', 'ch37', 'ch37'),
(38, 38, 'ch38.png', 'ch38', 'ch38', 'ch38', 'ch38', 'ch38', 'ch38'),
(39, 39, 'ch39.png', 'ch39', 'ch39', 'ch39', 'ch39', 'ch39', 'ch39'),
(40, 40, 'ch40.png', 'ch40', 'ch40', 'ch40', 'ch40', 'ch40', 'ch40'),
(41, 41, 'ch41.png', 'ch41', 'ch41', 'ch41', 'ch41', 'ch41', 'ch41'),
(42, 42, 'ch42.png', 'ch42', 'ch42', 'ch42', 'ch42', 'ch42', 'ch42'),
(43, 43, 'ch43.png', 'ch43', 'ch43', 'ch43', 'ch43', 'ch43', 'ch43'),
(44, 44, 'ch44.png', 'ch44', 'ch44', 'ch44', 'ch44', 'ch44', 'ch44'),
(45, 45, 'ch45.png', 'ch45', 'ch45', 'ch45', 'ch45', 'ch45', 'ch45'),
(46, 46, 'ch46.png', 'ch46', 'ch46', 'ch46', 'ch46', 'ch46', 'ch46'),
(47, 47, 'ch47.png', 'ch47', 'ch47', 'ch47', 'ch47', 'ch47', 'ch47'),
(48, 48, 'ch48.png', 'ch48', 'ch48', 'ch48', 'ch48', 'ch48', 'ch48'),
(49, 49, 'ch49.png', 'ch49', 'ch49', 'ch49', 'ch49', 'ch49', 'ch49'),
(50, 50, 'ch50.png', 'ch50', 'ch50', 'ch50', 'ch50', 'ch50', 'ch50'),
(51, 51, 'ch51.png', 'ch51', 'ch51', 'ch51', 'ch51', 'ch51', 'ch51'),
(52, 52, 'ch52.png', 'ch52', 'ch52', 'ch52', 'ch52', 'ch52', 'ch52'),
(53, 53, 'ch53.png', 'ch53', 'ch53', 'ch53', 'ch53', 'ch53', 'ch53'),
(54, 54, 'ch54.png', 'ch54', 'ch54', 'ch54', 'ch54', 'ch54', 'ch54'),
(55, 55, 'ch55.png', 'ch55', 'ch55', 'ch55', 'ch55', 'ch55', 'ch55'),
(56, 56, 'ch56.png', 'ch56', 'ch56', 'ch56', 'ch56', 'ch56', 'ch56'),
(57, 57, 'ch57.png', 'ch57', 'ch57', 'ch57', 'ch57', 'ch57', 'ch57'),
(58, 58, 'ch58.png', 'ch58', 'ch58', 'ch58', 'ch58', 'ch58', 'ch58'),
(59, 59, 'ch59.png', 'ch59', 'ch59', 'ch59', 'ch59', 'ch59', 'ch59'),
(60, 60, 'ch60.png', 'ch60', 'ch60', 'ch60', 'ch60', 'ch60', 'ch60'),
(61, 61, 'ch61.png', 'ch61', 'ch61', 'ch61', 'ch61', 'ch61', 'ch61'),
(62, 62, 'ch62.png', 'ch62', 'ch62', 'ch62', 'ch62', 'ch62', 'ch62'),
(63, 63, 'ch63.png', 'ch63', 'ch63', 'ch63', 'ch63', 'ch63', 'ch63'),
(64, 64, 'ch64.png', 'ch64', 'ch64', 'ch64', 'ch64', 'ch64', 'ch64'),
(65, 65, 'ch65.png', 'ch65', 'ch65', 'ch65', 'ch65', 'ch65', 'ch65'),
(66, 66, 'ch66.png', 'ch66', 'ch66', 'ch66', 'ch66', 'ch66', 'ch66'),
(67, 67, 'ch67.png', 'ch67', 'ch67', 'ch67', 'ch67', 'ch67', 'ch67'),
(68, 68, 'ch68.png', 'ch68', 'ch68', 'ch68', 'ch68', 'ch68', 'ch68'),
(69, 69, 'ch69.png', 'ch69', 'ch69', 'ch69', 'ch69', 'ch69', 'ch69'),
(70, 70, 'ch70.png', 'ch70', 'ch70', 'ch70', 'ch70', 'ch70', 'ch70'),
(71, 71, 'ch71.png', 'ch71', 'ch71', 'ch71', 'ch71', 'ch71', 'ch71'),
(72, 72, 'ch72.png', 'ch72', 'ch72', 'ch72', 'ch72', 'ch72', 'ch72'),
(73, 73, 'ch73.png', 'ch73', 'ch73', 'ch73', 'ch73', 'ch73', 'ch73'),
(74, 74, 'ch74.png', 'ch74', 'ch74', 'ch74', 'ch74', 'ch74', 'ch74'),
(75, 75, 'ch75.png', 'ch75', 'ch75', 'ch75', 'ch75', 'ch75', 'ch75'),
(76, 76, 'ch76.png', 'ch76', 'ch76', 'ch76', 'ch76', 'ch76', 'ch76'),
(77, 77, 'ch77.png', 'ch77', 'ch77', 'ch77', 'ch77', 'ch77', 'ch77'),
(78, 78, 'ch78.png', 'ch78', 'ch78', 'ch78', 'ch78', 'ch78', 'ch78'),
(79, 79, 'ch79.png', 'ch79', 'ch79', 'ch79', 'ch79', 'ch79', 'ch79'),
(80, 80, 'ch80.png', 'ch80', 'ch80', 'ch80', 'ch80', 'ch80', 'ch80'),
(81, 81, 'ch81.png', 'ch81', 'ch81', 'ch81', 'ch81', 'ch81', 'ch81'),
(82, 82, 'ch82.png', 'ch82', 'ch82', 'ch82', 'ch82', 'ch82', 'ch82'),
(83, 83, 'ch83.png', 'ch83', 'ch83', 'ch83', 'ch83', 'ch83', 'ch83'),
(84, 84, 'ch84.png', 'ch84', 'ch84', 'ch84', 'ch84', 'ch84', 'ch84'),
(85, 85, 'ch85.png', 'ch85', 'ch85', 'ch85', 'ch85', 'ch85', 'ch85'),
(86, 86, 'ch86.png', 'ch86', 'ch86', 'ch86', 'ch86', 'ch86', 'ch86'),
(87, 87, 'ch87.png', 'ch87', 'ch87', 'ch87', 'ch87', 'ch87', 'ch87'),
(88, 88, 'ch88.png', 'ch88', 'ch88', 'ch88', 'ch88', 'ch88', 'ch88'),
(89, 89, 'ch89.png', 'ch89', 'ch89', 'ch89', 'ch89', 'ch89', 'ch89'),
(90, 90, 'ch90.png', 'ch90', 'ch90', 'ch90', 'ch90', 'ch90', 'ch90'),
(91, 91, 'ch91.png', 'ch91', 'ch91', 'ch91', 'ch91', 'ch91', 'ch91'),
(92, 92, 'ch92.png', 'ch92', 'ch92', 'ch92', 'ch92', 'ch92', 'ch92'),
(93, 93, 'ch93.png', 'ch93', 'ch93', 'ch93', 'ch93', 'ch93', 'ch93'),
(94, 94, 'ch94.png', 'ch94', 'ch94', 'ch94', 'ch94', 'ch94', 'ch94'),
(95, 95, 'ch95.png', 'ch95', 'ch95', 'ch95', 'ch95', 'ch95', 'ch95'),
(96, 96, 'ch96.png', 'ch96', 'ch96', 'ch96', 'ch96', 'ch96', 'ch96'),
(97, 97, 'ch97.png', 'ch97', 'ch97', 'ch97', 'ch97', 'ch97', 'ch97'),
(98, 98, 'ch98.png', 'ch98', 'ch98', 'ch98', 'ch98', 'ch98', 'ch98'),
(99, 99, 'ch99.png', 'ch99', 'ch99', 'ch99', 'ch99', 'ch99', 'ch99'),
(100, 100, 'ch100.png', 'ch100', 'ch100', 'ch100', 'ch100', 'ch100', 'ch100'),
(101, 101, 'ch101.png', 'ch101', 'ch101', 'ch101', 'ch101', 'ch101', 'ch101'),
(102, 102, 'ch102.png', 'ch102', 'ch102', 'ch102', 'ch102', 'ch102', 'ch102'),
(103, 103, 'ch103.png', 'ch103', 'ch103', 'ch103', 'ch103', 'ch103', 'ch103'),
(104, 104, 'ch104.png', 'ch104', 'ch104', 'ch104', 'ch104', 'ch104', 'ch104'),
(105, 105, 'ch105.png', 'ch105', 'ch105', 'ch105', 'ch105', 'ch105', 'ch105'),
(106, 106, 'ch106.png', 'ch106', 'ch106', 'ch106', 'ch106', 'ch106', 'ch106'),
(107, 107, 'ch107.png', 'ch107', 'ch107', 'ch107', 'ch107', 'ch107', 'ch107'),
(108, 108, 'ch108.png', 'ch108', 'ch108', 'ch108', 'ch108', 'ch108', 'ch108'),
(109, 109, 'ch109.png', 'ch109', 'ch109', 'ch109', 'ch109', 'ch109', 'ch109'),
(110, 110, 'ch110.png', 'ch110', 'ch110', 'ch110', 'ch110', 'ch110', 'ch110'),
(111, 111, 'ch111.png', 'ch111', 'ch111', 'ch111', 'ch111', 'ch111', 'ch111'),
(112, 112, 'ch112.png', 'ch112', 'ch112', 'ch112', 'ch112', 'ch112', 'ch112'),
(113, 113, 'ch113.png', 'ch113', 'ch113', 'ch113', 'ch113', 'ch113', 'ch113'),
(114, 114, 'ch114.png', 'ch114', 'ch114', 'ch114', 'ch114', 'ch114', 'ch114'),
(115, 115, 'ch115.png', 'ch115', 'ch115', 'ch115', 'ch115', 'ch115', 'ch115'),
(116, 116, 'ch116.png', 'ch116', 'ch116', 'ch116', 'ch116', 'ch116', 'ch116'),
(117, 117, 'ch117.png', 'ch117', 'ch117', 'ch117', 'ch117', 'ch117', 'ch117'),
(118, 118, 'ch118.png', 'ch118', 'ch118', 'ch118', 'ch118', 'ch118', 'ch118'),
(119, 119, 'ch119.png', 'ch119', 'ch119', 'ch119', 'ch119', 'ch119', 'ch119'),
(120, 120, 'ch120.png', 'ch120', 'ch120', 'ch120', 'ch120', 'ch120', 'ch120'),
(121, 121, 'ch121.png', 'ch121', 'ch121', 'ch121', 'ch121', 'ch121', 'ch121'),
(122, 122, 'ch122.png', 'ch122', 'ch122', 'ch122', 'ch122', 'ch122', 'ch122'),
(123, 123, 'ch123.png', 'ch123', 'ch123', 'ch123', 'ch123', 'ch123', 'ch123'),
(124, 124, 'ch124.png', 'ch124', 'ch124', 'ch124', 'ch124', 'ch124', 'ch124'),
(125, 125, 'ch125.png', 'ch125', 'ch125', 'ch125', 'ch125', 'ch125', 'ch125'),
(126, 126, 'ch126.png', 'ch126', 'ch126', 'ch126', 'ch126', 'ch126', 'ch126'),
(127, 127, 'ch127.png', 'ch127', 'ch127', 'ch127', 'ch127', 'ch127', 'ch127'),
(128, 128, 'ch128.png', 'ch128', 'ch128', 'ch128', 'ch128', 'ch128', 'ch128'),
(129, 129, 'ch129.png', 'ch129', 'ch129', 'ch129', 'ch129', 'ch129', 'ch129'),
(130, 130, 'ch130.png', 'ch130', 'ch130', 'ch130', 'ch130', 'ch130', 'ch130'),
(131, 131, 'ch131.png', 'ch131', 'ch131', 'ch131', 'ch131', 'ch131', 'ch131'),
(132, 132, 'ch132.png', 'ch132', 'ch132', 'ch132', 'ch132', 'ch132', 'ch132'),
(133, 133, 'ch133.png', 'ch133', 'ch133', 'ch133', 'ch133', 'ch133', 'ch133'),
(134, 134, 'ch134.png', 'ch134', 'ch134', 'ch134', 'ch134', 'ch134', 'ch134'),
(135, 135, 'ch135.png', 'ch135', 'ch135', 'ch135', 'ch135', 'ch135', 'ch135'),
(136, 136, 'ch136.png', 'ch136', 'ch136', 'ch136', 'ch136', 'ch136', 'ch136'),
(137, 137, 'ch137.png', 'ch137', 'ch137', 'ch137', 'ch137', 'ch137', 'ch137'),
(138, 138, 'ch138.png', 'ch138', 'ch138', 'ch138', 'ch138', 'ch138', 'ch138'),
(139, 139, 'ch139.png', 'ch139', 'ch139', 'ch139', 'ch139', 'ch139', 'ch139'),
(140, 140, 'ch140.png', 'ch140', 'ch140', 'ch140', 'ch140', 'ch140', 'ch140'),
(141, 141, 'ch141.png', 'ch141', 'ch141', 'ch141', 'ch141', 'ch141', 'ch141'),
(142, 142, 'ch142.png', 'ch142', 'ch142', 'ch142', 'ch142', 'ch142', 'ch142'),
(143, 143, 'ch143.png', 'ch143', 'ch143', 'ch143', 'ch143', 'ch143', 'ch143'),
(144, 144, 'ch144.png', 'ch144', 'ch144', 'ch144', 'ch144', 'ch144', 'ch144'),
(145, 145, 'ch145.png', 'ch145', 'ch145', 'ch145', 'ch145', 'ch145', 'ch145'),
(146, 146, 'ch146.png', 'ch146', 'ch146', 'ch146', 'ch146', 'ch146', 'ch146'),
(147, 147, 'ch147.png', 'ch147', 'ch147', 'ch147', 'ch147', 'ch147', 'ch147'),
(148, 148, 'ch148.png', 'ch148', 'ch148', 'ch148', 'ch148', 'ch148', 'ch148'),
(149, 149, 'ch149.png', 'ch149', 'ch149', 'ch149', 'ch149', 'ch149', 'ch149'),
(150, 150, 'ch150.png', 'ch150', 'ch150', 'ch150', 'ch150', 'ch150', 'ch150'),
(151, 151, 'ch151.png', 'ch151', 'ch151', 'ch151', 'ch151', 'ch151', 'ch151'),
(152, 152, 'ch152.png', 'ch152', 'ch152', 'ch152', 'ch152', 'ch152', 'ch152'),
(153, 153, 'ch153.png', 'ch153', 'ch153', 'ch153', 'ch153', 'ch153', 'ch153'),
(154, 154, 'ch154.png', 'ch154', 'ch154', 'ch154', 'ch154', 'ch154', 'ch154'),
(155, 155, 'ch155.png', 'ch155', 'ch155', 'ch155', 'ch155', 'ch155', 'ch155'),
(156, 156, 'ch156.png', 'ch156', 'ch156', 'ch156', 'ch156', 'ch156', 'ch156'),
(157, 157, 'ch157.png', 'ch157', 'ch157', 'ch157', 'ch157', 'ch157', 'ch157'),
(158, 158, 'ch158.png', 'ch158', 'ch158', 'ch158', 'ch158', 'ch158', 'ch158'),
(159, 159, 'ch159.png', 'ch159', 'ch159', 'ch159', 'ch159', 'ch159', 'ch159'),
(160, 160, 'ch160.png', 'ch160', 'ch160', 'ch160', 'ch160', 'ch160', 'ch160'),
(161, 161, 'ch161.png', 'ch161', 'ch161', 'ch161', 'ch161', 'ch161', 'ch161'),
(162, 162, 'ch162.png', 'ch162', 'ch162', 'ch162', 'ch162', 'ch162', 'ch162'),
(163, 163, 'ch163.png', 'ch163', 'ch163', 'ch163', 'ch163', 'ch163', 'ch163'),
(164, 164, 'ch164.png', 'ch164', 'ch164', 'ch164', 'ch164', 'ch164', 'ch164'),
(165, 165, 'ch165.png', 'ch165', 'ch165', 'ch165', 'ch165', 'ch165', 'ch165'),
(166, 166, 'ch166.png', 'ch166', 'ch166', 'ch166', 'ch166', 'ch166', 'ch166'),
(167, 167, 'ch167.png', 'ch167', 'ch167', 'ch167', 'ch167', 'ch167', 'ch167'),
(168, 168, 'ch168.png', 'ch168', 'ch168', 'ch168', 'ch168', 'ch168', 'ch168'),
(169, 169, 'ch169.png', 'ch169', 'ch169', 'ch169', 'ch169', 'ch169', 'ch169'),
(170, 170, 'ch170.png', 'ch170', 'ch170', 'ch170', 'ch170', 'ch170', 'ch170'),
(171, 171, 'ch171.png', 'ch171', 'ch171', 'ch171', 'ch171', 'ch171', 'ch171'),
(172, 172, 'ch172.png', 'ch172', 'ch172', 'ch172', 'ch172', 'ch172', 'ch172'),
(173, 173, 'ch173.png', 'ch173', 'ch173', 'ch173', 'ch173', 'ch173', 'ch173'),
(174, 174, 'ch174.png', 'ch174', 'ch174', 'ch174', 'ch174', 'ch174', 'ch174'),
(175, 175, 'ch175.png', 'ch175', 'ch175', 'ch175', 'ch175', 'ch175', 'ch175'),
(176, 176, 'ch176.png', 'ch176', 'ch176', 'ch176', 'ch176', 'ch176', 'ch176'),
(177, 177, 'ch177.png', 'ch177', 'ch177', 'ch177', 'ch177', 'ch177', 'ch177'),
(178, 178, 'ch178.png', 'ch178', 'ch178', 'ch178', 'ch178', 'ch178', 'ch178'),
(179, 179, 'ch179.png', 'ch179', 'ch179', 'ch179', 'ch179', 'ch179', 'ch179'),
(180, 180, 'ch180.png', 'ch180', 'ch180', 'ch180', 'ch180', 'ch180', 'ch180'),
(181, 181, 'ch181.png', 'ch181', 'ch181', 'ch181', 'ch181', 'ch181', 'ch181'),
(182, 182, 'ch182.png', 'ch182', 'ch182', 'ch182', 'ch182', 'ch182', 'ch182'),
(183, 183, 'ch183.png', 'ch183', 'ch183', 'ch183', 'ch183', 'ch183', 'ch183'),
(184, 184, 'ch184.png', 'ch184', 'ch184', 'ch184', 'ch184', 'ch184', 'ch184'),
(185, 185, 'ch185.png', 'ch185', 'ch185', 'ch185', 'ch185', 'ch185', 'ch185'),
(186, 186, 'ch186.png', 'ch186', 'ch186', 'ch186', 'ch186', 'ch186', 'ch186'),
(187, 187, 'ch187.png', 'ch187', 'ch187', 'ch187', 'ch187', 'ch187', 'ch187'),
(188, 188, 'ch188.png', 'ch188', 'ch188', 'ch188', 'ch188', 'ch188', 'ch188'),
(189, 189, 'ch189.png', 'ch189', 'ch189', 'ch189', 'ch189', 'ch189', 'ch189'),
(190, 190, 'ch190.png', 'ch190', 'ch190', 'ch190', 'ch190', 'ch190', 'ch190'),
(191, 191, 'ch191.png', 'ch191', 'ch191', 'ch191', 'ch191', 'ch191', 'ch191'),
(192, 192, 'ch192.png', 'ch192', 'ch192', 'ch192', 'ch192', 'ch192', 'ch192'),
(193, 193, 'ch193.png', 'ch193', 'ch193', 'ch193', 'ch193', 'ch193', 'ch193'),
(194, 194, 'ch194.png', 'ch194', 'ch194', 'ch194', 'ch194', 'ch194', 'ch194'),
(195, 195, 'ch195.png', 'ch195', 'ch195', 'ch195', 'ch195', 'ch195', 'ch195'),
(196, 196, 'ch196.png', 'ch196', 'ch196', 'ch196', 'ch196', 'ch196', 'ch196'),
(197, 197, 'ch197.png', 'ch197', 'ch197', 'ch197', 'ch197', 'ch197', 'ch197'),
(198, 198, 'ch198.png', 'ch198', 'ch198', 'ch198', 'ch198', 'ch198', 'ch198'),
(199, 199, 'ch199.png', 'ch199', 'ch199', 'ch199', 'ch199', 'ch199', 'ch199'),
(200, 200, 'ch200.png', 'ch200', 'ch200', 'ch200', 'ch200', 'ch200', 'ch200'),
(201, 201, 'ch201.png', 'ch201', 'ch201', 'ch201', 'ch201', 'ch201', 'ch201'),
(202, 202, 'ch202.png', 'ch202', 'ch202', 'ch202', 'ch202', 'ch202', 'ch202'),
(203, 203, 'ch203.png', 'ch203', 'ch203', 'ch203', 'ch203', 'ch203', 'ch203'),
(204, 204, 'ch204.png', 'ch204', 'ch204', 'ch204', 'ch204', 'ch204', 'ch204'),
(205, 205, 'ch205.png', 'ch205', 'ch205', 'ch205', 'ch205', 'ch205', 'ch205'),
(206, 206, 'ch206.png', 'ch206', 'ch206', 'ch206', 'ch206', 'ch206', 'ch206'),
(207, 207, 'ch207.png', 'ch207', 'ch207', 'ch207', 'ch207', 'ch207', 'ch207'),
(208, 208, 'ch208.png', 'ch208', 'ch208', 'ch208', 'ch208', 'ch208', 'ch208'),
(209, 209, 'ch209.png', 'ch209', 'ch209', 'ch209', 'ch209', 'ch209', 'ch209'),
(210, 210, 'ch210.png', 'ch210', 'ch210', 'ch210', 'ch210', 'ch210', 'ch210'),
(211, 211, 'ch211.png', 'ch211', 'ch211', 'ch211', 'ch211', 'ch211', 'ch211'),
(212, 212, 'ch212.png', 'ch212', 'ch212', 'ch212', 'ch212', 'ch212', 'ch212'),
(213, 213, 'ch213.png', 'ch213', 'ch213', 'ch213', 'ch213', 'ch213', 'ch213'),
(214, 214, 'ch214.png', 'ch214', 'ch214', 'ch214', 'ch214', 'ch214', 'ch214'),
(215, 215, 'ch215.png', 'ch215', 'ch215', 'ch215', 'ch215', 'ch215', 'ch215'),
(216, 216, 'ch216.png', 'ch216', 'ch216', 'ch216', 'ch216', 'ch216', 'ch216'),
(217, 217, 'ch217.png', 'ch217', 'ch217', 'ch217', 'ch217', 'ch217', 'ch217'),
(218, 218, 'ch218.png', 'ch218', 'ch218', 'ch218', 'ch218', 'ch218', 'ch218'),
(219, 219, 'ch219.png', 'ch219', 'ch219', 'ch219', 'ch219', 'ch219', 'ch219'),
(220, 220, 'ch220.png', 'ch220', 'ch220', 'ch220', 'ch220', 'ch220', 'ch220'),
(221, 221, 'ch221.png', 'ch221', 'ch221', 'ch221', 'ch221', 'ch221', 'ch221'),
(222, 222, 'ch222.png', 'ch222', 'ch222', 'ch222', 'ch222', 'ch222', 'ch222'),
(223, 223, 'ch223.png', 'ch223', 'ch223', 'ch223', 'ch223', 'ch223', 'ch223'),
(224, 224, 'ch224.png', 'ch224', 'ch224', 'ch224', 'ch224', 'ch224', 'ch224'),
(225, 225, 'ch225.png', 'ch225', 'ch225', 'ch225', 'ch225', 'ch225', 'ch225'),
(226, 226, 'ch226.png', 'ch226', 'ch226', 'ch226', 'ch226', 'ch226', 'ch226'),
(227, 227, 'ch227.png', 'ch227', 'ch227', 'ch227', 'ch227', 'ch227', 'ch227'),
(228, 228, 'ch228.png', 'ch228', 'ch228', 'ch228', 'ch228', 'ch228', 'ch228'),
(229, 229, 'ch229.png', 'ch229', 'ch229', 'ch229', 'ch229', 'ch229', 'ch229'),
(230, 230, 'ch230.png', 'ch230', 'ch230', 'ch230', 'ch230', 'ch230', 'ch230'),
(231, 231, 'ch231.png', 'ch231', 'ch231', 'ch231', 'ch231', 'ch231', 'ch231'),
(232, 232, 'ch232.png', 'ch232', 'ch232', 'ch232', 'ch232', 'ch232', 'ch232'),
(233, 233, 'ch233.png', 'ch233', 'ch233', 'ch233', 'ch233', 'ch233', 'ch233'),
(234, 234, 'ch234.png', 'ch234', 'ch234', 'ch234', 'ch234', 'ch234', 'ch234'),
(235, 235, 'ch235.png', 'ch235', 'ch235', 'ch235', 'ch235', 'ch235', 'ch235'),
(236, 236, 'ch236.png', 'ch236', 'ch236', 'ch236', 'ch236', 'ch236', 'ch236'),
(237, 237, 'ch237.png', 'ch237', 'ch237', 'ch237', 'ch237', 'ch237', 'ch237'),
(238, 238, 'ch238.png', 'ch238', 'ch238', 'ch238', 'ch238', 'ch238', 'ch238'),
(239, 239, 'ch239.png', 'ch239', 'ch239', 'ch239', 'ch239', 'ch239', 'ch239'),
(240, 240, 'ch240.png', 'ch240', 'ch240', 'ch240', 'ch240', 'ch240', 'ch240'),
(241, 241, 'ch241.png', 'ch241', 'ch241', 'ch241', 'ch241', 'ch241', 'ch241'),
(242, 242, 'ch242.png', 'ch242', 'ch242', 'ch242', 'ch242', 'ch242', 'ch242'),
(243, 243, 'ch243.png', 'ch243', 'ch243', 'ch243', 'ch243', 'ch243', 'ch243'),
(244, 244, 'ch244.png', 'ch244', 'ch244', 'ch244', 'ch244', 'ch244', 'ch244'),
(245, 245, 'ch245.png', 'ch245', 'ch245', 'ch245', 'ch245', 'ch245', 'ch245'),
(246, 246, 'ch246.png', 'ch246', 'ch246', 'ch246', 'ch246', 'ch246', 'ch246'),
(247, 247, 'ch247.png', 'ch247', 'ch247', 'ch247', 'ch247', 'ch247', 'ch247'),
(248, 248, 'ch248.png', 'ch248', 'ch248', 'ch248', 'ch248', 'ch248', 'ch248'),
(249, 249, 'ch249.png', 'ch249', 'ch249', 'ch249', 'ch249', 'ch249', 'ch249'),
(250, 250, 'ch250.png', 'ch250', 'ch250', 'ch250', 'ch250', 'ch250', 'ch250'),
(251, 251, 'ch251.png', 'ch251', 'ch251', 'ch251', 'ch251', 'ch251', 'ch251'),
(252, 252, 'ch252.png', 'ch252', 'ch252', 'ch252', 'ch252', 'ch252', 'ch252'),
(253, 253, 'ch253.png', 'ch253', 'ch253', 'ch253', 'ch253', 'ch253', 'ch253'),
(254, 254, 'ch254.png', 'ch254', 'ch254', 'ch254', 'ch254', 'ch254', 'ch254'),
(255, 255, 'ch255.png', 'ch255', 'ch255', 'ch255', 'ch255', 'ch255', 'ch255'),
(256, 256, 'ch256.png', 'ch256', 'ch256', 'ch256', 'ch256', 'ch256', 'ch256'),
(257, 257, 'ch257.png', 'ch257', 'ch257', 'ch257', 'ch257', 'ch257', 'ch257'),
(258, 258, 'ch258.png', 'ch258', 'ch258', 'ch258', 'ch258', 'ch258', 'ch258'),
(259, 259, 'ch259.png', 'ch259', 'ch259', 'ch259', 'ch259', 'ch259', 'ch259'),
(260, 260, 'ch260.png', 'ch260', 'ch260', 'ch260', 'ch260', 'ch260', 'ch260'),
(261, 261, 'ch261.png', 'ch261', 'ch261', 'ch261', 'ch261', 'ch261', 'ch261'),
(262, 262, 'ch262.png', 'ch262', 'ch262', 'ch262', 'ch262', 'ch262', 'ch262'),
(263, 263, 'ch263.png', 'ch263', 'ch263', 'ch263', 'ch263', 'ch263', 'ch263'),
(264, 264, 'ch264.png', 'ch264', 'ch264', 'ch264', 'ch264', 'ch264', 'ch264'),
(265, 265, 'ch265.png', 'ch265', 'ch265', 'ch265', 'ch265', 'ch265', 'ch265'),
(266, 266, 'ch266.png', 'ch266', 'ch266', 'ch266', 'ch266', 'ch266', 'ch266'),
(267, 267, 'ch267.png', 'ch267', 'ch267', 'ch267', 'ch267', 'ch267', 'ch267'),
(268, 268, 'ch268.png', 'ch268', 'ch268', 'ch268', 'ch268', 'ch268', 'ch268'),
(269, 269, 'ch269.png', 'ch269', 'ch269', 'ch269', 'ch269', 'ch269', 'ch269'),
(270, 270, 'ch270.png', 'ch270', 'ch270', 'ch270', 'ch270', 'ch270', 'ch270'),
(271, 271, 'ch271.png', 'ch271', 'ch271', 'ch271', 'ch271', 'ch271', 'ch271'),
(272, 272, 'ch272.png', 'ch272', 'ch272', 'ch272', 'ch272', 'ch272', 'ch272'),
(273, 273, 'ch273.png', 'ch273', 'ch273', 'ch273', 'ch273', 'ch273', 'ch273'),
(274, 274, 'ch274.png', 'ch274', 'ch274', 'ch274', 'ch274', 'ch274', 'ch274'),
(275, 275, 'ch275.png', 'ch275', 'ch275', 'ch275', 'ch275', 'ch275', 'ch275'),
(276, 276, 'ch276.png', 'ch276', 'ch276', 'ch276', 'ch276', 'ch276', 'ch276'),
(277, 277, 'ch277.png', 'ch277', 'ch277', 'ch277', 'ch277', 'ch277', 'ch277'),
(278, 278, 'ch278.png', 'ch278', 'ch278', 'ch278', 'ch278', 'ch278', 'ch278'),
(279, 279, 'ch279.png', 'ch279', 'ch279', 'ch279', 'ch279', 'ch279', 'ch279'),
(280, 280, 'ch280.png', 'ch280', 'ch280', 'ch280', 'ch280', 'ch280', 'ch280'),
(281, 281, 'ch281.png', 'ch281', 'ch281', 'ch281', 'ch281', 'ch281', 'ch281'),
(282, 282, 'ch282.png', 'ch282', 'ch282', 'ch282', 'ch282', 'ch282', 'ch282'),
(283, 283, 'ch283.png', 'ch283', 'ch283', 'ch283', 'ch283', 'ch283', 'ch283'),
(284, 284, 'ch284.png', 'ch284', 'ch284', 'ch284', 'ch284', 'ch284', 'ch284'),
(285, 285, 'ch285.png', 'ch285', 'ch285', 'ch285', 'ch285', 'ch285', 'ch285'),
(286, 286, 'ch286.png', 'ch286', 'ch286', 'ch286', 'ch286', 'ch286', 'ch286'),
(287, 287, 'ch287.png', 'ch287', 'ch287', 'ch287', 'ch287', 'ch287', 'ch287'),
(288, 288, 'ch288.png', 'ch288', 'ch288', 'ch288', 'ch288', 'ch288', 'ch288'),
(289, 289, 'ch289.png', 'ch289', 'ch289', 'ch289', 'ch289', 'ch289', 'ch289'),
(290, 290, 'ch290.png', 'ch290', 'ch290', 'ch290', 'ch290', 'ch290', 'ch290'),
(291, 291, 'ch291.png', 'ch291', 'ch291', 'ch291', 'ch291', 'ch291', 'ch291'),
(292, 292, 'ch292.png', 'ch292', 'ch292', 'ch292', 'ch292', 'ch292', 'ch292'),
(293, 293, 'ch293.png', 'ch293', 'ch293', 'ch293', 'ch293', 'ch293', 'ch293'),
(294, 294, 'ch294.png', 'ch294', 'ch294', 'ch294', 'ch294', 'ch294', 'ch294'),
(295, 295, 'ch295.png', 'ch295', 'ch295', 'ch295', 'ch295', 'ch295', 'ch295'),
(296, 296, 'ch296.png', 'ch296', 'ch296', 'ch296', 'ch296', 'ch296', 'ch296'),
(297, 297, 'ch297.png', 'ch297', 'ch297', 'ch297', 'ch297', 'ch297', 'ch297'),
(298, 298, 'ch298.png', 'ch298', 'ch298', 'ch298', 'ch298', 'ch298', 'ch298'),
(299, 299, 'ch299.png', 'ch299', 'ch299', 'ch299', 'ch299', 'ch299', 'ch299'),
(300, 300, 'ch300.png', 'ch300', 'ch300', 'ch300', 'ch300', 'ch300', 'ch300'),
(301, 301, 'ch301.png', 'ch301', 'ch301', 'ch301', 'ch301', 'ch301', 'ch301'),
(302, 302, 'ch302.png', 'ch302', 'ch302', 'ch302', 'ch302', 'ch302', 'ch302'),
(303, 303, 'ch303.png', 'ch303', 'ch303', 'ch303', 'ch303', 'ch303', 'ch303'),
(304, 304, 'ch304.png', 'ch304', 'ch304', 'ch304', 'ch304', 'ch304', 'ch304'),
(305, 305, 'ch305.png', 'ch305', 'ch305', 'ch305', 'ch305', 'ch305', 'ch305'),
(306, 306, 'ch306.png', 'ch306', 'ch306', 'ch306', 'ch306', 'ch306', 'ch306'),
(307, 307, 'ch307.png', 'ch307', 'ch307', 'ch307', 'ch307', 'ch307', 'ch307'),
(308, 308, 'ch308.png', 'ch308', 'ch308', 'ch308', 'ch308', 'ch308', 'ch308'),
(309, 309, 'ch309.png', 'ch309', 'ch309', 'ch309', 'ch309', 'ch309', 'ch309'),
(310, 310, 'ch310.png', 'ch310', 'ch310', 'ch310', 'ch310', 'ch310', 'ch310');

-- --------------------------------------------------------

--
-- Table structure for table `destroy`
--

CREATE TABLE `destroy` (
  `id` int(11) NOT NULL,
  `destroyID` varchar(11) NOT NULL,
  `money` int(11) NOT NULL,
  `oil` int(11) NOT NULL,
  `coin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `destroy`
--

INSERT INTO `destroy` (`id`, `destroyID`, `money`, `oil`, `coin`) VALUES
(1, 'ch1', 4, 3, 4);

-- --------------------------------------------------------

--
-- Table structure for table `detail`
--

CREATE TABLE `detail` (
  `id` int(11) NOT NULL,
  `charecterID` int(3) NOT NULL,
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `rarity` int(5) NOT NULL,
  `nationality` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `class` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `hullType` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `TimeToCreate` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `upgrade` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `destroy` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `detail`
--

INSERT INTO `detail` (`id`, `charecterID`, `name`, `rarity`, `nationality`, `class`, `hullType`, `TimeToCreate`, `location`, `upgrade`, `destroy`) VALUES
(1, 1, 'Universal Bullin', 4, 'Universal', 'DD', 'Destroyer', 'None', 'None', 'None', 'ch1');

-- --------------------------------------------------------

--
-- Table structure for table `drops`
--

CREATE TABLE `drops` (
  `id` int(11) NOT NULL,
  `drops` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `dropsList` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `drops`
--

INSERT INTO `drops` (`id`, `drops`, `dropsList`) VALUES
(1, 'None', 'None'),
(2, 'A55', 'Z-16');

-- --------------------------------------------------------

--
-- Table structure for table `introduce`
--

CREATE TABLE `introduce` (
  `id` int(11) NOT NULL,
  `introduce` varchar(100) CHARACTER SET utf8 NOT NULL,
  `weapon1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `weapon2` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `introduce`
--

INSERT INTO `introduce` (`id`, `introduce`, `weapon1`, `weapon2`) VALUES
(1, 'ch1', 'None', 'None');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `id` int(11) NOT NULL,
  `state` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `stateName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `level` int(2) NOT NULL,
  `cadition` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `exp` int(5) NOT NULL,
  `picture` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `drops` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `state`, `stateName`, `level`, `cadition`, `exp`, `picture`, `drops`) VALUES
(1, 'Event', 'Events & Questions', 0, 'None', 0, 'None', 'None');

-- --------------------------------------------------------

--
-- Table structure for table `skill`
--

CREATE TABLE `skill` (
  `id` int(11) NOT NULL,
  `skill` varchar(100) CHARACTER SET utf8 NOT NULL,
  `skillName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `eff` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `skill`
--

INSERT INTO `skill` (`id`, `skill`, `skillName`, `eff`) VALUES
(1, 'ch1', 'เพิ่มดาว', 'สามารถเพิ่มดาวให้กับเรือยกเว้นสีทอง'),
(2, 's10', 'aaaa', 'aaaa');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id` int(11) NOT NULL,
  `status` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `hp` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `atk` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `defFly` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `dodge` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `atkFly` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `atkTPD` varchar(11) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id`, `status`, `hp`, `atk`, `defFly`, `dodge`, `atkFly`, `atkTPD`) VALUES
(1, 'ch1', 'D', 'D', 'D', 'D', 'D', 'D');

-- --------------------------------------------------------

--
-- Table structure for table `updates`
--

CREATE TABLE `updates` (
  `id` int(11) NOT NULL,
  `updateID` varchar(11) NOT NULL,
  `atk` int(11) NOT NULL,
  `def` int(11) NOT NULL,
  `fly` int(11) NOT NULL,
  `reload` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `updates`
--

INSERT INTO `updates` (`id`, `updateID`, `atk`, `def`, `fly`, `reload`) VALUES
(1, 'None', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `weapon`
--

CREATE TABLE `weapon` (
  `id` int(11) NOT NULL,
  `weaponID` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `wapon` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `canUse` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `atk` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `uptoAtk` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `upAtk` int(11) NOT NULL,
  `cd` int(11) NOT NULL,
  `uptoCD` int(11) NOT NULL,
  `eff` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `ranges` int(11) NOT NULL,
  `angle` int(11) NOT NULL,
  `ammunition` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `far` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `weapon`
--

INSERT INTO `weapon` (`id`, `weaponID`, `wapon`, `canUse`, `atk`, `uptoAtk`, `upAtk`, `cd`, `uptoCD`, `eff`, `location`, `ranges`, `angle`, `ammunition`, `far`) VALUES
(1, '', 'AD-Ckaio 100', 'cv', '12', '122', 11, 21, 11, 'ddd555', '1-1 5-1', 12, 12, 'A', 'A');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `beginstatus`
--
ALTER TABLE `beginstatus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `charecter`
--
ALTER TABLE `charecter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `destroy`
--
ALTER TABLE `destroy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `detail`
--
ALTER TABLE `detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `drops`
--
ALTER TABLE `drops`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `introduce`
--
ALTER TABLE `introduce`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skill`
--
ALTER TABLE `skill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `updates`
--
ALTER TABLE `updates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `weapon`
--
ALTER TABLE `weapon`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `beginstatus`
--
ALTER TABLE `beginstatus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `charecter`
--
ALTER TABLE `charecter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=311;
--
-- AUTO_INCREMENT for table `destroy`
--
ALTER TABLE `destroy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `detail`
--
ALTER TABLE `detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `drops`
--
ALTER TABLE `drops`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `introduce`
--
ALTER TABLE `introduce`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `skill`
--
ALTER TABLE `skill`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `updates`
--
ALTER TABLE `updates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `weapon`
--
ALTER TABLE `weapon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

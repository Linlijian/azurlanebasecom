-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 15, 2017 at 11:35 AM
-- Server version: 10.1.20-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id3259161_charecterdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `BeginStatus`
--

CREATE TABLE `BeginStatus` (
  `id` int(11) NOT NULL,
  `beginstatus` varchar(100) CHARACTER SET utf8 NOT NULL,
  `hp` int(11) NOT NULL,
  `def` varchar(11) CHARACTER SET utf8 NOT NULL,
  `cd` int(11) NOT NULL,
  `atk` int(11) NOT NULL,
  `atkTPD` int(11) NOT NULL,
  `dodge` int(11) NOT NULL,
  `defFly` int(11) NOT NULL,
  `atkFly` int(11) NOT NULL,
  `depetion` int(11) NOT NULL,
  `speed` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `BeginStatus`
--

INSERT INTO `BeginStatus` (`id`, `beginstatus`, `hp`, `def`, `cd`, `atk`, `atkTPD`, `dodge`, `defFly`, `atkFly`, `depetion`, `speed`) VALUES
(1, 's10', 292, 'medime', 76, 14, 89, 73, 33, 0, 2, 44);

-- --------------------------------------------------------

--
-- Table structure for table `Charecter`
--

CREATE TABLE `Charecter` (
  `id` int(11) NOT NULL,
  `charectorID` int(3) NOT NULL,
  `picture` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `beginStatus` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `skill` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `introduce` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Charecter`
--

INSERT INTO `Charecter` (`id`, `charectorID`, `picture`, `status`, `beginStatus`, `skill`, `introduce`) VALUES
(1, 10, '10.jpg', 's10', 's10', 's10', 's10'),
(2, 32, '32.jpg', 's32', 's32', 's32', 's32');

-- --------------------------------------------------------

--
-- Table structure for table `Detail`
--

CREATE TABLE `Detail` (
  `id` int(11) NOT NULL,
  `charecterID` int(3) NOT NULL,
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `star` int(5) NOT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `grade` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `camp` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `TimeToCreate` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `upgrade` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `destroy` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Detail`
--

INSERT INTO `Detail` (`id`, `charecterID`, `name`, `star`, `type`, `grade`, `camp`, `TimeToCreate`, `location`, `upgrade`, `destroy`) VALUES
(1, 10, 'USS Maury', 2, 'ขับไล่', 'สีม่วง', ' นกอินทรีสีขาว', '00:25:00', '收藏中收集格里德利级船只.', '5:28:0:14', '4:3:4');

-- --------------------------------------------------------

--
-- Table structure for table `Drops`
--

CREATE TABLE `Drops` (
  `id` int(11) NOT NULL,
  `drops` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `dropsList` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Drops`
--

INSERT INTO `Drops` (`id`, `drops`, `dropsList`) VALUES
(1, 'A55', 'Z-17'),
(2, 'A55', 'Z-16');

-- --------------------------------------------------------

--
-- Table structure for table `Introduce`
--

CREATE TABLE `Introduce` (
  `id` int(11) NOT NULL,
  `introduce` varchar(100) CHARACTER SET utf8 NOT NULL,
  `weapon1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `weapon2` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Introduce`
--

INSERT INTO `Introduce` (`id`, `introduce`, `weapon1`, `weapon2`) VALUES
(1, 's10', 'A++', 'B++');

-- --------------------------------------------------------

--
-- Table structure for table `Location`
--

CREATE TABLE `Location` (
  `id` int(11) NOT NULL,
  `state` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `stateName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `level` int(2) NOT NULL,
  `cadition` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `exp` int(5) NOT NULL,
  `picture` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `drops` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Location`
--

INSERT INTO `Location` (`id`, `state`, `stateName`, `level`, `cadition`, `exp`, `picture`, `drops`) VALUES
(1, '2-1', 'ADdd State', 25, 'pass / kill 20+ / kill boss', 600, '2-1.jpg', 'A55');

-- --------------------------------------------------------

--
-- Table structure for table `Skill`
--

CREATE TABLE `Skill` (
  `id` int(11) NOT NULL,
  `skill` varchar(100) CHARACTER SET utf8 NOT NULL,
  `skillName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `eff` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Skill`
--

INSERT INTO `Skill` (`id`, `skill`, `skillName`, `eff`) VALUES
(1, 's10', 'asdqqq', 'dddww'),
(2, 's10', 'aaaa', 'aaaa');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id` int(11) NOT NULL,
  `status` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `hp` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `atk` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `defFly` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `dodge` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `atkFly` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `atkTPD` varchar(11) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id`, `status`, `hp`, `atk`, `defFly`, `dodge`, `atkFly`, `atkTPD`) VALUES
(1, 's10', 'C', 'C', 'C', 'A', 'E', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `Weapon`
--

CREATE TABLE `Weapon` (
  `id` int(11) NOT NULL,
  `wapon` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `canUse` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `atk` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `uptoAtk` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `upAtk` int(11) NOT NULL,
  `cd` int(11) NOT NULL,
  `uptoCD` int(11) NOT NULL,
  `eff` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `ranges` int(11) NOT NULL,
  `angle` int(11) NOT NULL,
  `ammunition` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `far` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Weapon`
--

INSERT INTO `Weapon` (`id`, `wapon`, `canUse`, `atk`, `uptoAtk`, `upAtk`, `cd`, `uptoCD`, `eff`, `location`, `ranges`, `angle`, `ammunition`, `far`) VALUES
(1, 'AD-Ckaio 100', 'cv', '12', '122', 11, 21, 11, 'ddd555', '1-1 5-1', 12, 12, 'A', 'A');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `BeginStatus`
--
ALTER TABLE `BeginStatus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Charecter`
--
ALTER TABLE `Charecter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Detail`
--
ALTER TABLE `Detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Drops`
--
ALTER TABLE `Drops`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Introduce`
--
ALTER TABLE `Introduce`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Location`
--
ALTER TABLE `Location`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Skill`
--
ALTER TABLE `Skill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Weapon`
--
ALTER TABLE `Weapon`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `BeginStatus`
--
ALTER TABLE `BeginStatus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Charecter`
--
ALTER TABLE `Charecter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `Detail`
--
ALTER TABLE `Detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Drops`
--
ALTER TABLE `Drops`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `Introduce`
--
ALTER TABLE `Introduce`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Location`
--
ALTER TABLE `Location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Skill`
--
ALTER TABLE `Skill`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Weapon`
--
ALTER TABLE `Weapon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
